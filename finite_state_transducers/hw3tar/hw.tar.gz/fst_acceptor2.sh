#!/bin/sh

python3 fst_acceptor2.py $@