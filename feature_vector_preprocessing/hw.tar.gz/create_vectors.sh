#!/bin/sh

python3 create_vectors.py $@